<nav id="mainmenu">
    <ul>
        <li><a href="index.php">Hem</a></li>
        <li><a href="about.php">Variabler</a></li>
        <li><a href="contact.php">Villkor</a></li>
        <li><a href="contact.php">Upprepningar</a></li>
        <li><a href="contact.php">Formulär</a></li>
        <li><a href="contact.php">Läsa textfil</a></li>
    </ul>
</nav>