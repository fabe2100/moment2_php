<footer id="mainfooter">
    <p>Moment 2 PHP . Webbutveckling II.</p>
</footer><!-- /mainfooter -->
</div><!-- /container -->
</body>

</html>