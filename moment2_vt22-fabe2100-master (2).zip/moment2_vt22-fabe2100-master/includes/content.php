<section>
    <div class="content">
        <h1>Frågor och svar av Moment 2</h1>

        <ol>

            <li><strong>Har du tidigare erfarenhet av utveckling med PHP?</strong>
                <p>Det här är mitt alldeles första försök att börja lära mig det nya språket PHP. </p>
            </li>

            <li><strong>Beskriv kortfattat vad du upplever är fördelarna med att använda PHP för att skapa webbplatser.</strong>

                <p>Den mest använbar funktionalitet som PHP ser till att erbjuda, är att man kan undvika att göra uppraepad gånger de förändringar man gjort på en sida. Man slipper helt enkelt att modifiera i alla de undersidor.<br>
                    Det blir lättare att jobba med att skapa en sida på det sättet.</p>
            </li>

            <li><strong>Hur har du valt att strukturera upp dina filer och kataloger?</strong>

                <p>Jag har skapat en index sida som jag sen klippte ut till olika delar som varje del ska vara på en specifik fil. <br> Som att ha en fil för header( Uppgiftens titel och meny), en för content (som innehöll liksom sidans innehåll), en för mainmenu och en för footer. <br>
                    Allt detta hade jag inkluderat inom filen includes.
                    Förutom index.php filen så hade jag också skapat en css fil för att styla alla mina undersidor. </p>
            </li>

            <li><strong>Har du följt guiden, eller skapat på egen hand?</strong>

                <p>Jag har inte skapat något nytt struktur utan har följt guiden som finns under teori delen.<br> För varje del av momentet har jag skapat en php fil.
                    Det blev variables.php för variabel delen, loops.php för loopar, form.php för formuläret, conditions.php för villkor, readtxt.php för att läsa in den externa filen och calculate.php för att beräkna area.

                </p>
            </li>

            <li><strong>Har du gjort några förbättringar eller vidareutvecklingar av guiden (om du följt denna)?</strong>

                <p> Det blev bara små förändringar som jag gjorde på guiden som att jag har skippat att ha några filer för sidebar.
                    Jag har valt att ha en enkel sida med innehållet i mitten av sidan, utan att ha en två spalts-design. Allt annat har jag följt enligt guiden för den tyckte jag är lätt hanterlig.</p>
            </li>

            <li><strong>Vilken utvecklingsmiljö har du använt för att genomföra uppgiften (editor, webbserver-paket (Xampp, Lamp, Wamp eller liknande)?</strong>
                <p>Jag har en Linux operativ system så valde jag att ladda ner XAMPP som funkar bra på de olika operativsystemen <br>
                    Jag arbetade sen efter att laddat klar och testat att XAMPP funkar och är helt ok med Visual Stuido Code som editor för att skapa mina sidor för PHP momentet.</p>
            </li>

            <li><strong>Har något varit svårt med denna uppgift?</strong>

                <p>Det var uppgiften med att konvertera dagen för att den ska skrivas på svenska till skärmen, samt uppgiften med att att räkna bredd och höjd för att få fram area. </p>
            </li>

        </ol>
    </div>
</section>