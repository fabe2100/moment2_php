<?php
//includes header file
include("includes/header.php");
?>
<?php include("includes/mainmenu.php.php"); ?>
<?php include("includes/content.php"); ?>

<?php
//includes footer file
include("includes/footer.php"); ?>

       