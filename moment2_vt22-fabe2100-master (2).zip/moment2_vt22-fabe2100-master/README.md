### Moment2_vt22-fabe2100 (Fauzia Bensliman)
I den här uppgiften arbetade jag med att skapa en enkel sida med php. Huvudmenyn, headern, content och footer har jag skapat som externa filer och som ska inkluderas i själva index sidan och andra undersidor.

Jag skapade också olika filer för de olika del uppgifterna, en för varje samtidigt som jag såg till att alltid jobba paralellt med Github för att få först filenrna där på Github classrom och alla andra ändringar jag gjort med stage, commit och push.



